import {
  InjectionToken
} from "./chunk-AF2GL2QR.js";

// node_modules/@angular/material/fesm2022/input-value-accessor-8a79a24e.mjs
var MAT_INPUT_VALUE_ACCESSOR = new InjectionToken("MAT_INPUT_VALUE_ACCESSOR");

export {
  MAT_INPUT_VALUE_ACCESSOR
};
//# sourceMappingURL=chunk-GW5AF2D3.js.map
